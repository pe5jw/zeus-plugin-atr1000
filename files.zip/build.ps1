<#
.SYNOPSIS
  Build the ATR-1000 Zeus plugin and package it as a distributable zip.

.PARAMETER ZeusRepo
  Path to a local clone of openhpsdr-zeus (must contain
  Zeus.Plugins.Contracts\Zeus.Plugins.Contracts.csproj).
  Defaults to ..\openhpsdr-zeus (sibling of this repo).

.PARAMETER Configuration
  Build configuration: Release (default) or Debug.

.PARAMETER SkipUi
  Skip the npm / Vite UI build (useful when only changing backend code).

.EXAMPLE
  .\build.ps1
  .\build.ps1 -ZeusRepo C:\src\openhpsdr-zeus
  .\build.ps1 -SkipUi
#>
param(
    [string] $ZeusRepo      = "..\openhpsdr-zeus",
    [string] $Configuration = "Release",
    [switch] $SkipUi
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$Root    = $PSScriptRoot
$Dist    = Join-Path $Root "dist"
$Version = (Get-Content (Join-Path $Root "plugin.json") | ConvertFrom-Json).version

Write-Host ""
Write-Host "=== ATR-1000 Zeus plugin — build v$Version ===" -ForegroundColor Cyan
Write-Host ""

# ── 1. UI (Vite) ──────────────────────────────────────────────────────────
if (-not $SkipUi) {
    Write-Host "--- Building UI (npm + vite) ---" -ForegroundColor Yellow
    Push-Location $Root
    try {
        npm install --prefer-offline
        if ($LASTEXITCODE -ne 0) { throw "npm install failed" }
        npm run build
        if ($LASTEXITCODE -ne 0) { throw "vite build failed" }
    } finally { Pop-Location }
} else {
    Write-Host "--- Skipping UI build (--SkipUi) ---" -ForegroundColor DarkGray
}

# ── 2. Backend (.NET) ─────────────────────────────────────────────────────
Write-Host ""
Write-Host "--- Building backend (dotnet $Configuration) ---" -ForegroundColor Yellow

$ContractsProj = Join-Path (Resolve-Path $ZeusRepo) `
    "Zeus.Plugins.Contracts\Zeus.Plugins.Contracts.csproj"

if (-not (Test-Path $ContractsProj)) {
    Write-Error @"
Zeus.Plugins.Contracts not found at:
  $ContractsProj

Clone openhpsdr-zeus next to this repo, or pass the correct path:
  .\build.ps1 -ZeusRepo C:\path\to\openhpsdr-zeus
"@
}

dotnet build "$Root\Atr1000.csproj" `
    -c $Configuration `
    "/p:ZeusContractsProject=$ContractsProj"
if ($LASTEXITCODE -ne 0) { throw "dotnet build failed" }

# ── 3. Assemble dist ──────────────────────────────────────────────────────
Write-Host ""
Write-Host "--- Assembling dist/ ---" -ForegroundColor Yellow

$BinDir = Join-Path $Root "bin\$Configuration\net10.0"
Remove-Item $Dist -Recurse -Force -ErrorAction SilentlyContinue
New-Item $Dist -ItemType Directory | Out-Null
New-Item (Join-Path $Dist "ui") -ItemType Directory | Out-Null

Copy-Item (Join-Path $Root "plugin.json")        $Dist
Copy-Item (Join-Path $BinDir "Atr1000.dll")      $Dist
Copy-Item (Join-Path $Root "ui\atr1000.es.js")   (Join-Path $Dist "ui")

# ── 4. Zip ────────────────────────────────────────────────────────────────
$ZipName = "atr1000-$Version.zip"
$ZipPath = Join-Path $Root $ZipName
Remove-Item $ZipPath -Force -ErrorAction SilentlyContinue
Compress-Archive -Path "$Dist\*" -DestinationPath $ZipPath
Write-Host ""
Write-Host "=== Done: $ZipName ===" -ForegroundColor Green

# Print SHA-256 for the registry entry.
$Hash = (Get-FileHash $ZipPath -Algorithm SHA256).Hash.ToLower()
Write-Host "SHA-256 : $Hash" -ForegroundColor Cyan
Write-Host ""
Write-Host "Paste that hash into registry-entry.json -> versions[0].sha256"
